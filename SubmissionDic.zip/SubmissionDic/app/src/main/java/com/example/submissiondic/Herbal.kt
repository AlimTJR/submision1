package com.example.submissiondic

data class Herbal(
    var name : String="",
    var ilmiah : String="",
    var detail : String="",
    var photo : Int = 0
)