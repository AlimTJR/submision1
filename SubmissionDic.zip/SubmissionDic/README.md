# Submission Dicoding Belajar Membuat Aplikasi Android untuk Pemula
# Feature 
List View with Data <br>
Detail item for each data <br>
Profile Page <br>

Screen Shoot
